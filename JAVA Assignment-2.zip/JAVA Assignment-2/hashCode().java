public class Main {
  public static void main(String[] args) {
    String myStr = "Hello";
    System.out.println(myStr.hashCode());
  }
}
