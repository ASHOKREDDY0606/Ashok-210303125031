public class Main {
  public static void main(String[] args) {
    String myStr = "Hello";
    System.out.println(myStr.startsWith("Hel"));
    System.out.println(myStr.startsWith("llo"));
    System.out.println(myStr.startsWith("o"));
  }
}