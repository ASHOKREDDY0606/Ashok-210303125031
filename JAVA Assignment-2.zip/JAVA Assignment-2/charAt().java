public class Main {
  public static void main(String[] args) {
    String myStr = "Hello";
    char result = myStr.charAt(0);
    System.out.println(result);
  }
}