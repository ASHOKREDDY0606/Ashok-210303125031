public class ReplaceAllExample1{  
public static void main(String args[]){  
String s1="javatpoint is a very good website";  
String replaceString=s1.replaceAll("a","e");  
System.out.println(replaceString);  
}}