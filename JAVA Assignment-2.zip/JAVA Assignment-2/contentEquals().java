public class Main {
  public static void main(String[] args) {
    String myStr = "Hello";
    System.out.println(myStr.contentEquals("Hello"));
    System.out.println(myStr.contentEquals("e"));
    System.out.println(myStr.contentEquals("Hi"));
  }
}
