public class Main {
  public static void main(String[] args) {
    String myStr1 = "Hello";
    String myStr2 = "";
    System.out.println(myStr1.isEmpty());
    System.out.println(myStr2.isEmpty());
  }
}