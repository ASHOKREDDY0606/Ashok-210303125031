public class Main {
  public static void main(String[] args) {
    String myStr = "Hello";
    System.out.println(myStr.endsWith("Hel"));
    System.out.println(myStr.endsWith("llo"));
    System.out.println(myStr.endsWith("o"));
  }
}
